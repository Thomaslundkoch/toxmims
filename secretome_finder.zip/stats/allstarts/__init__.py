

"""Top-level package for allstarts"""

__version__ = "0.1.0"