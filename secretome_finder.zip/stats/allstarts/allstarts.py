"""This module provides allstarts main module"""

import regex as re

class Sequences:
    def __init__(self, input_file):
        self._startgenerator = _StartGenerator(input_file)

    def find_starts(self):
        starts = self._startgenerator.build_starts()

class _StartGenerator:
    def __init__(self, input_file):
        self._sequences = {}
        self.input_file = input_file

    def get_sequences(self):
        title = ''
        with open(self.input_file, 'r') as reader:
            for line in reader:
                line = line.rstrip()
                if line.startswith('>'):
                    if title == '':     #deal with first sequence
                        title = line.replace(' ', '_')
                        sequence = ''
                    else:
                        self._sequences[title] = sequence
                        title = line.replace(' ', '_')
                        sequence = ''
                else:
                    sequence += line

    def build_starts(self):
        self.get_sequences()
        for key in self._sequences:
            sequence = self._sequences[key]
            matches = re.findall('M[A-Z]*', sequence, overlapped=True)
            n = 1
            for match in matches:
                if len(match) > 50:
                    print(f'{key}#{n}')
                    print(f'{match}')
                    n += 1
