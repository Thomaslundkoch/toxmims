"""This module provides the allstarts CLI"""


import argparse

from . import __version__
from .allstarts import Sequences #names!

def main():
    args = parse_cmd_line_arguments()
    input_file = args.input_file
    input_type = args.type
    if input_type == 'prot':
        #print('Protein types')
        multiple_starts = Sequences(input_file)
        multiple_starts.find_starts()
    elif input_type == 'nucl':
        #print('Nucleotide types')
        multiple_starts = Sequences(input_file)
        multiple_starts.find_starts()

def parse_cmd_line_arguments():
    parser = argparse.ArgumentParser(
        prog="starter",
        description="allstarts, a generator of all possible starts of sequences",
        epilog="Thank you for finding a start point!"
    )
    parser.version = f"allstarts v{__version__}"
    parser.add_argument("-v", "--version", action="version")
    parser.add_argument(
        'input_file',
        help="generate all subsequences starting with M from sequences in file"
    )
    parser.add_argument(
        "-t", "--type",
        help="input type of sequences; prot = protein, nucl = nucleotide",
        choices=['prot','nucl']
    )
    return parser.parse_args()