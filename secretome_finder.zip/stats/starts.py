#!/usr/bin/env python3

"""This module provides allstarts entry point script

Issues and considerations:
  - what kind of sequences should we  include? If we only go for the sequences with signal peptides we will end up with:
    * false positives: anything with a signal peptide, such as enzymes etc
    * false negatives: some transcripts might be truncated, such that it encodes the C-terminal region of a conotoxin,
      but it is missing the signal sequence, so it will be removed from the pool
    Alternatives:
      * blast-hits from conotoxin search
      * current machine learning algorithm (which seems pretty old-fashioned and with known limitations)
      * remake a machine learning algorithm, most likely using RNN (this for sure seems doable, but it would likely
        take at least a week to implement)

TODO:
  - implement different starting points for analysis - prot vs nucleotide:
    * figure out smartest way to call command line arguments from python (subprocess seems the way to go)

"""

from allstarts.cli import main

if __name__ == "__main__":
    main()